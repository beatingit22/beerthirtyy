'use strict';
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const api = window.b30;

const S = { cfg: null, instances: [], selected: '', view: 'home', launch: 'idle', filter: '' };

/* ---------- helpers ---------- */
function rng(seed) { let t = seed >>> 0; return () => { t += 0x6D2B79F5; let r = Math.imul(t ^ (t >>> 15), 1 | t); r ^= r + Math.imul(r ^ (r >>> 7), 61 | r); return ((r ^ (r >>> 14)) >>> 0) / 4294967296; }; }
function hash(s) { let h = 2166136261; for (const c of s) { h ^= c.charCodeAt(0); h = Math.imul(h, 16777619); } return h >>> 0; }
function ago(ms) {
  if (!ms) return 'Never played';
  const d = Date.now() - ms, m = 60e3, h = 60 * m, dd = 24 * h;
  if (d < m) return 'Just now'; if (d < h) return Math.floor(d / m) + ' min ago';
  if (d < dd) return Math.floor(d / h) + ' h ago'; if (d < 30 * dd) return Math.floor(d / dd) + ' d ago';
  return new Date(ms).toLocaleDateString();
}
function hours(sec) { const h = sec / 3600; return h >= 100 ? Math.round(h) + 'h' : (Math.round(h * 10) / 10) + 'h'; }
function toast(msg, kind = '') {
  const t = document.createElement('div'); t.className = 'toast ' + kind; t.textContent = msg; $('#toasts').appendChild(t);
  setTimeout(() => { t.style.transition = 'opacity .4s, transform .4s'; t.style.opacity = 0; t.style.transform = 'translateX(30px)'; setTimeout(() => t.remove(), 450); }, 5200);
}

/* procedural mountain cover, unique per instance */
const coverCache = {};
function cover(seed, w = 400, h = 200) {
  const key = seed + w; if (coverCache[key]) return coverCache[key];
  const r = rng(hash(seed)), hue = 205 + Math.floor(r() * 30);
  let layers = '';
  for (let L = 0; L < 3; L++) {
    let d = `M0 ${h}`; const base = h * (0.52 + L * 0.14), amp = h * (0.34 - L * 0.07), n = 9 + L * 3;
    for (let i = 0; i <= n; i++) { const x = (w / n) * i, y = base - r() * amp * (i % 2 ? 1 : 0.35); d += ` L${x.toFixed(0)} ${y.toFixed(0)}`; }
    d += ` L${w} ${h} Z`;
    const top = ['#ffffff', '#dceefc', '#b5d6f3'][L], mid = [`hsl(${hue} 55% 62%)`, `hsl(${hue} 55% 42%)`, `hsl(${hue} 60% 24%)`][L], bot = `hsl(${hue} 65% ${[30, 20, 12][L]}%)`;
    layers += `<linearGradient id="g${L}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${top}"/><stop offset=".16" stop-color="${mid}"/><stop offset="1" stop-color="${bot}"/></linearGradient><path d="${d}" fill="url(#g${L})"/>`;
  }
  const sx = (0.15 + r() * 0.7) * w;
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${w} ${h}" preserveAspectRatio="xMidYMid slice"><defs><linearGradient id="sky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="hsl(${hue + 10} 70% 14%)"/><stop offset="1" stop-color="hsl(${hue} 60% 52%)"/></linearGradient><radialGradient id="sun"><stop offset="0" stop-color="#fff" stop-opacity=".95"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient></defs><rect width="${w}" height="${h}" fill="url(#sky)"/><circle cx="${sx}" cy="${h * 0.3}" r="${h * 0.34}" fill="url(#sun)"/>${layers}</svg>`;
  return (coverCache[key] = 'data:image/svg+xml;utf8,' + encodeURIComponent(svg));
}

/* ---------- big background mountains ---------- */
function buildRidges() {
  const svg = $('#ridges'), r = rng(30), W = 1600, H = 420; let out = '';
  const noise = n => { const v = Array.from({ length: n + 3 }, () => r()); return x => { const i = Math.floor(x), f = x - i, s = f * f * (3 - 2 * f); return v[i] * (1 - s) + v[i + 1] * s; }; };
  const layers = [
    { y: 0.46, amp: 215, f: 3.2, top: '#c9def3', mid: '#7fa6d4', bot: '#1c316c', o: 0.30, k: 5 },
    { y: 0.62, amp: 190, f: 4.4, top: '#e0f0fd', mid: '#6b9bd0', bot: '#152a5c', o: 0.62, k: 11 },
    { y: 0.80, amp: 150, f: 5.8, top: '#bcd9f2', mid: '#3a69a8', bot: '#0b1740', o: 0.96, k: 19 }
  ];
  layers.forEach((L, i) => {
    const ns = [noise(24), noise(48), noise(96)];
    let d = `M-60 ${H}`;
    for (let x = -60; x <= W + 60; x += 8) {
      let h = 0, amp = 1, tot = 0;
      for (let o = 0; o < 3; o++) { const n = ns[o]((x + 60) / W * L.f * Math.pow(2, o) + 0.5); h += amp * (1 - Math.abs(2 * n - 1)); tot += amp; amp *= 0.46; }
      h = Math.pow(h / tot, 1.7);
      d += ` L${x} ${(H * L.y - h * L.amp).toFixed(1)}`;
    }
    d += ` L${W + 60} ${H} Z`;
    out += `<defs><linearGradient id="rg${i}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${L.top}"/><stop offset=".2" stop-color="${L.mid}"/><stop offset=".62" stop-color="${L.bot}"/><stop offset="1" stop-color="#050a1c"/></linearGradient></defs><g data-k="${L.k}" opacity="${L.o}"><path d="${d}" fill="url(#rg${i})"/></g>`;
  });
  out += `<defs><linearGradient id="fog" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#050a1c" stop-opacity="0"/><stop offset="1" stop-color="#050a1c" stop-opacity=".96"/></linearGradient></defs><rect x="0" y="${H * 0.58}" width="${W}" height="${H * 0.42}" fill="url(#fog)"/>`;
  svg.innerHTML = out;
}

/* ---------- snow ---------- */
const snow = { c: $('#snow'), flakes: [], on: true };
function snowInit() {
  const c = snow.c, dpr = Math.min(window.devicePixelRatio || 1, 2);
  c.width = innerWidth * dpr; c.height = innerHeight * dpr; snow.dpr = dpr;
  const n = Math.round(innerWidth * innerHeight / 9000);
  snow.flakes = Array.from({ length: n }, () => mk(true));
}
function mk(anywhere) { const z = Math.random(); return { x: Math.random() * innerWidth, y: anywhere ? Math.random() * innerHeight : -10, z, r: 0.6 + z * 2.4, v: 0.25 + z * 1.0, s: Math.random() * 6.28, w: 0.3 + Math.random() * 0.8 }; }
function snowLoop() {
  const c = snow.c, g = c.getContext('2d'); g.setTransform(snow.dpr, 0, 0, snow.dpr, 0, 0); g.clearRect(0, 0, innerWidth, innerHeight);
  if (snow.on) {
    for (const f of snow.flakes) {
      f.s += 0.01 * f.w; f.y += f.v; f.x += Math.sin(f.s) * 0.35 * f.w + (pointer.x * f.z * 0.25);
      if (f.y > innerHeight + 10 || f.x < -20 || f.x > innerWidth + 20) Object.assign(f, mk(false), { x: Math.random() * innerWidth });
      g.globalAlpha = 0.25 + f.z * 0.6; g.fillStyle = '#eaf5fd'; g.beginPath(); g.arc(f.x, f.y, f.r, 0, 6.283); g.fill();
    }
    g.globalAlpha = 1;
  }
  requestAnimationFrame(snowLoop);
}

/* ---------- parallax ---------- */
const pointer = { x: 0, y: 0, tx: 0, ty: 0 };
addEventListener('mousemove', e => { pointer.tx = (e.clientX / innerWidth - 0.5) * 2; pointer.ty = (e.clientY / innerHeight - 0.5) * 2; });
function parallaxLoop() {
  if (S.cfg && S.cfg.parallax) { pointer.x += (pointer.tx - pointer.x) * 0.06; pointer.y += (pointer.ty - pointer.y) * 0.06; }
  else { pointer.x += (0 - pointer.x) * 0.06; pointer.y += (0 - pointer.y) * 0.06; }
  const root = document.documentElement.style; root.setProperty('--mx', pointer.x.toFixed(3)); root.setProperty('--my', pointer.y.toFixed(3));
  $$('#ridges g').forEach(g => { const k = +g.dataset.k; g.style.transform = `translate(${(-pointer.x * k).toFixed(1)}px, ${(-pointer.y * k * 0.5).toFixed(1)}px)`; });
  requestAnimationFrame(parallaxLoop);
}

/* ---------- views ---------- */
function setView(v) {
  S.view = v;
  $$('.view').forEach(x => x.classList.toggle('active', x.id === 'view-' + v));
  $$('.nav').forEach(x => x.classList.toggle('active', x.dataset.view === v));
  $('#enginePill'); if (v === 'settings') fillSettings();
}
$('#rail').addEventListener('click', e => { const b = e.target.closest('.nav'); if (b) setView(b.dataset.view); });
$$('.winbtns button').forEach(b => b.addEventListener('click', () => api.win(b.dataset.win)));

/* ---------- instances / home ---------- */
const sel = () => S.instances.find(i => i.id === S.selected);
function metaOf(i) { return [i.mc && ('Minecraft ' + i.mc), i.loader].filter(Boolean).join(' · ') || 'Minecraft'; }
function renderStats() {
  $('#stInst').textContent = S.instances.length;
  $('#stHours').textContent = hours(S.instances.reduce((a, i) => a + i.played, 0));
  const last = [...S.instances].sort((a, b) => b.lastLaunch - a.lastLaunch)[0];
  $('#stLast').textContent = last && last.lastLaunch ? last.name : '—';
}
function renderPicker() {
  const i = sel(), has = !!i;
  $('#pickName').textContent = has ? i.name : 'No instance found';
  $('#pickMeta').textContent = has ? metaOf(i) : 'Open the engine to create one';
  $('#pickThumb').src = cover(has ? i.id : 'none', 120, 120);
  $('#pickMenu').innerHTML = S.instances.map(x => `<button class="opt ${x.id === S.selected ? 'sel' : ''}" data-id="${x.id}"><img class="thumb" src="${cover(x.id, 120, 120)}" alt=""><span><b>${esc(x.name)}</b><small>${esc(metaOf(x))} · ${ago(x.lastLaunch)}</small></span></button>`).join('');
  updateLaunchBtn();
}
function esc(s) { return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
function updateLaunchBtn() {
  const b = $('#launchBtn'), l = $('#launchLbl'), canGo = !!sel() && (S.cfg.enginePath || api.demo);
  b.classList.toggle('busy', S.launch === 'launching'); b.classList.toggle('running', S.launch === 'running');
  l.textContent = S.launch === 'launching' ? 'LAUNCHING' : S.launch === 'running' ? 'PLAYING' : 'LAUNCH';
  b.disabled = !canGo || S.launch !== 'idle';
  const hint = $('#emptyHint');
  if (!api.demo && !S.cfg.enginePath) { hint.hidden = false; hint.textContent = 'Engine not found. Open Settings and choose beer30launcher.exe.'; }
  else if (!S.instances.length) { hint.hidden = false; hint.textContent = 'No instances yet. Use “Manage accounts & instances” in Library to sign in and create one.'; }
  else hint.hidden = true;
}
function select(id) { S.selected = id; api.setConfig({ lastInstance: id }); renderPicker(); renderLibrary(); }
$('#pickBtn').addEventListener('click', e => { e.stopPropagation(); $('#picker').classList.toggle('open'); });
addEventListener('click', () => $('#picker').classList.remove('open'));
$('#pickMenu').addEventListener('click', e => { const o = e.target.closest('.opt'); if (o) select(o.dataset.id); });
$('#serverIn').addEventListener('change', e => { S.cfg.server = e.target.value; api.setConfig({ server: e.target.value }); });

async function doLaunch(id) {
  if (S.launch !== 'idle') return;
  if (id && id !== S.selected) select(id);
  const i = sel(); if (!i) return;
  const r = await api.launch({ id: i.id, server: $('#serverIn').value });
  if (!r.ok) toast(r.error || 'Could not start.', 'err');
}
$('#launchBtn').addEventListener('click', () => doLaunch());
api.onState(st => {
  S.launch = st.state; updateLaunchBtn();
  if (st.state === 'launching') toast('Launching ' + (sel() ? sel().name : '') + '…');
  if (st.state === 'running') toast('Game is running. Enjoy the pour.', 'ok');
  if (st.state === 'idle') { if (st.error) toast(st.error, 'err'); loadInstances(true); }
});

/* ---------- library ---------- */
function renderLibrary() {
  const q = S.filter.toLowerCase(), list = S.instances.filter(i => i.name.toLowerCase().includes(q));
  $('#libSub').textContent = S.instances.length + (S.instances.length === 1 ? ' instance' : ' instances');
  $('#libGrid').innerHTML = list.length ? list.map((i, n) => `
    <div class="card ${i.id === S.selected ? 'sel' : ''}" data-id="${i.id}" style="animation-delay:${n * 55}ms">
      <img class="cover" src="${cover(i.id, 520, 260)}" alt="">
      <div class="body"><h4>${esc(i.name)}</h4>
        <div class="chips">${i.mc ? `<span class="chip">${esc(i.mc)}</span>` : ''}${i.loader ? `<span class="chip ld">${esc(i.loader)}</span>` : ''}</div>
        <div class="meta"><span>${hours(i.played)} played<br>${ago(i.lastLaunch)}</span><button class="play" data-play="${i.id}" aria-label="Play"><svg viewBox="0 0 24 24"><path d="M6 3.5v17l15-8.5z"/></svg></button></div>
      </div></div>`).join('') : `<div class="lib-empty glass">${S.instances.length ? 'No instances match your search.' : 'No instances found yet. Use “Manage accounts & instances” to sign in and create one.'}</div>`;
}
$('#libGrid').addEventListener('click', e => {
  const p = e.target.closest('[data-play]'); if (p) { e.stopPropagation(); setView('home'); doLaunch(p.dataset.play); return; }
  const c = e.target.closest('.card'); if (c) select(c.dataset.id);
});
$('#libSearch').addEventListener('input', e => { S.filter = e.target.value; renderLibrary(); });
async function openEngine() { const r = await api.openEngine(); if (!r.ok) toast(r.error, 'err'); else toast('Engine window opened.'); }
$('#openEngine2').addEventListener('click', openEngine);
$('#openEngine3').addEventListener('click', openEngine);

/* ---------- settings ---------- */
function applyLook() {
  snow.on = !!S.cfg.effects;
  document.documentElement.style.setProperty('--blur', S.cfg.blur + 'px');
}
function fillSettings() {
  $('#enginePath').value = S.cfg.enginePath || ''; $('#dataDir').value = S.cfg.dataDir || '';
  $('#swEffects').checked = !!S.cfg.effects; $('#swParallax').checked = !!S.cfg.parallax;
  $('#blurRange').value = S.cfg.blur; $('#blurVal').textContent = S.cfg.blur + 'px';
}
async function patch(p) { S.cfg = await api.setConfig(p); applyLook(); }
$('#swEffects').addEventListener('change', e => patch({ effects: e.target.checked }));
$('#swParallax').addEventListener('change', e => patch({ parallax: e.target.checked }));
$('#blurRange').addEventListener('input', e => { $('#blurVal').textContent = e.target.value + 'px'; S.cfg.blur = +e.target.value; applyLook(); });
$('#blurRange').addEventListener('change', e => patch({ blur: +e.target.value }));
$('#browseEngine').addEventListener('click', async () => { const p = await api.pickEngine(); if (p) { await patch({ enginePath: p }); await refresh(); fillSettings(); } });
$('#browseData').addEventListener('click', async () => { const p = await api.pickFolder(); if (p) { await patch({ dataDir: p, dataDirManual: true }); await refresh(); fillSettings(); } });
$('#openData').addEventListener('click', () => api.openFolder(S.cfg.dataDir));
$('#autoDetect').addEventListener('click', async () => { await patch({ enginePath: '', dataDir: '', dataDirManual: false }); S.cfg = await api.detect(); await refresh(); fillSettings(); toast(S.cfg.enginePath ? 'Engine found.' : 'Could not find the engine. Use Browse.', S.cfg.enginePath ? 'ok' : 'err'); });

/* ---------- boot ---------- */
function renderPill() {
  const p = $('#enginePill'), ok = api.demo || (S.cfg.enginePath && S.instances.length >= 0 && S.cfg.dataDir);
  const okEngine = api.demo || !!S.cfg.enginePath;
  p.className = 'pill ' + (okEngine && (api.demo || S.cfg.dataDir) ? 'ok' : S.cfg.enginePath ? '' : 'bad');
  p.querySelector('span').textContent = api.demo ? 'Preview mode' : okEngine ? (S.cfg.dataDir ? 'Engine ready' : 'Engine found · no data folder') : 'Engine not found';
}
async function loadInstances(keep) {
  S.instances = await api.listInstances();
  if (!keep || !sel()) S.selected = (S.instances.find(i => i.id === S.cfg.lastInstance) || S.instances[0] || {}).id || '';
  renderStats(); renderPicker(); renderLibrary(); renderPill();
}
async function refresh() { await loadInstances(false); }
async function boot() {
  S.cfg = await api.detect(); applyLook();
  $('#serverIn').value = S.cfg.server || '';
  buildRidges(); snowInit(); snowLoop(); parallaxLoop();
  addEventListener('resize', snowInit);
  await loadInstances(false);
  if (new URLSearchParams(location.search).get('view')) setView(new URLSearchParams(location.search).get('view'));
}
boot();
