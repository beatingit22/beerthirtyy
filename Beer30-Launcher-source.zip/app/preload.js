const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('b30', {
  getConfig: () => ipcRenderer.invoke('cfg:get'),
  setConfig: (patch) => ipcRenderer.invoke('cfg:set', patch),
  detect: () => ipcRenderer.invoke('detect'),
  pickEngine: () => ipcRenderer.invoke('pick:engine'),
  pickFolder: () => ipcRenderer.invoke('pick:folder'),
  listInstances: () => ipcRenderer.invoke('instances:list'),
  launch: (payload) => ipcRenderer.invoke('launch', payload),
  openEngine: () => ipcRenderer.invoke('engine:open'),
  openFolder: (p) => ipcRenderer.invoke('folder:open', p),
  win: (action) => ipcRenderer.send('win', action),
  onState: (cb) => ipcRenderer.on('state', (_e, s) => cb(s)),
  demo: process.env.B30_DEMO === '1'
});
