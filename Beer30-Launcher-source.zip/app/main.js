const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { spawn } = require('child_process');

const DEMO = process.env.B30_DEMO === '1';
const IS_WIN = process.platform === 'win32';
const ENGINE_NAMES = IS_WIN ? ['beer30launcher.exe'] : ['beer30launcher', 'beer30launcher.exe'];
let win = null;
let child = null;
let runningTimer = null;

// ---------- config ----------
const defaults = { enginePath: '', dataDir: '', dataDirManual: false, server: '', effects: true, parallax: true, blur: 22, lastInstance: '' };
const cfgFile = () => path.join(app.getPath('userData'), 'config.json');
function loadCfg() {
  try { return { ...defaults, ...JSON.parse(fs.readFileSync(cfgFile(), 'utf8')) }; }
  catch { return { ...defaults }; }
}
function saveCfg(c) {
  if (DEMO) return;
  fs.mkdirSync(path.dirname(cfgFile()), { recursive: true });
  fs.writeFileSync(cfgFile(), JSON.stringify(c, null, 2));
}

// ---------- auto-detect the engine (the Beer30 launcher exe) and its data folder ----------
function listDir(d) { try { return fs.readdirSync(d, { withFileTypes: true }); } catch { return []; } }
function findEngineIn(dir, depth) {
  for (const e of listDir(dir)) {
    if (e.isFile() && ENGINE_NAMES.includes(e.name.toLowerCase())) return path.join(dir, e.name);
  }
  if (depth > 0) {
    for (const e of listDir(dir)) {
      if (e.isDirectory() && !e.name.startsWith('.') && e.name !== 'node_modules') {
        const r = findEngineIn(path.join(dir, e.name), depth - 1);
        if (r) return r;
      }
    }
  }
  return '';
}
function detectEngine() {
  const exeDir = path.dirname(process.execPath);
  const home = os.homedir();
  const roots = [exeDir, path.dirname(exeDir), path.dirname(path.dirname(exeDir)),
    path.join(home, 'Downloads'), path.join(home, 'Desktop'), path.join(home, 'Documents')];
  for (const r of roots) { const f = findEngineIn(r, r === exeDir ? 3 : 2); if (f) return f; }
  return '';
}
function hasInstances(d) { try { return fs.statSync(path.join(d, 'instances')).isDirectory(); } catch { return false; } }
function detectDataDir(enginePath) {
  if (enginePath) {
    const ed = path.dirname(enginePath);
    if (fs.existsSync(path.join(ed, 'portable.txt')) && hasInstances(ed)) return ed;
  }
  const bases = [process.env.APPDATA, process.env.LOCALAPPDATA, path.join(os.homedir(), '.local', 'share')].filter(Boolean);
  const names = ['Beer30Launcher', 'Beer30 Launcher', 'beer30launcher', 'BEER30LAUNCHER', 'PrismLauncher'];
  for (const b of bases) for (const n of names) {
    const p = path.join(b, n);
    if (hasInstances(p)) return p;
    if (hasInstances(path.join(p, n))) return path.join(p, n);
  }
  for (const b of bases) for (const e of listDir(b)) {
    if (e.isDirectory() && /beer30/i.test(e.name)) {
      const p = path.join(b, e.name);
      if (hasInstances(p)) return p;
      for (const s of listDir(p)) if (s.isDirectory() && hasInstances(path.join(p, s.name))) return path.join(p, s.name);
    }
  }
  return '';
}

// ---------- read instances (instance.cfg + mmc-pack.json) ----------
function parseIni(text) {
  const o = {};
  for (const line of text.split(/\r?\n/)) {
    const i = line.indexOf('=');
    if (i > 0 && !line.startsWith('[') && !line.startsWith(';')) o[line.slice(0, i).trim()] = line.slice(i + 1).trim();
  }
  return o;
}
const LOADERS = {
  'net.fabricmc.fabric-loader': 'Fabric', 'net.minecraftforge': 'Forge', 'net.neoforged': 'NeoForge',
  'org.quiltmc.quilt-loader': 'Quilt', 'com.mumfrey.liteloader': 'LiteLoader'
};
function readInstances(dataDir) {
  if (DEMO) {
    const now = Date.now();
    return [
      { id: 'demo1', name: 'Beer30 Survival', mc: '1.21.11', loader: 'Fabric', played: 185400, lastLaunch: now - 3600e3 },
      { id: 'demo2', name: 'Prison Grind', mc: '1.21.11', loader: 'Fabric', played: 98000, lastLaunch: now - 26 * 3600e3 },
      { id: 'demo3', name: 'Vanilla Clean', mc: '1.21.4', loader: '', played: 12600, lastLaunch: now - 6 * 86400e3 },
      { id: 'demo4', name: 'Modpack Testing', mc: '1.20.1', loader: 'Forge', played: 4300, lastLaunch: 0 }
    ];
  }
  if (!dataDir) return [];
  const root = path.join(dataDir, 'instances');
  const out = [];
  for (const e of listDir(root)) {
    if (!e.isDirectory() || e.name.startsWith('.') || e.name.startsWith('_')) continue;
    const dir = path.join(root, e.name);
    let cfg = {};
    try { cfg = parseIni(fs.readFileSync(path.join(dir, 'instance.cfg'), 'utf8')); } catch { continue; }
    let mc = '', loader = '';
    try {
      const pack = JSON.parse(fs.readFileSync(path.join(dir, 'mmc-pack.json'), 'utf8'));
      for (const c of pack.components || []) {
        if (c.uid === 'net.minecraft') mc = c.version || '';
        if (LOADERS[c.uid]) loader = LOADERS[c.uid];
      }
    } catch {}
    out.push({
      id: e.name, name: cfg.name || e.name, mc, loader,
      played: parseInt(cfg.totalTimePlayed || '0', 10) || 0,
      lastLaunch: parseInt(cfg.lastLaunchTime || '0', 10) || 0
    });
  }
  out.sort((a, b) => b.lastLaunch - a.lastLaunch || a.name.localeCompare(b.name));
  return out;
}

// ---------- window ----------
function send(ch, payload) { if (win && !win.isDestroyed()) win.webContents.send(ch, payload); }
function createWindow() {
  win = new BrowserWindow({
    width: 1280, height: 780, minWidth: 1040, minHeight: 660,
    frame: false, backgroundColor: '#060b1f', show: false, title: 'Beer30 Launcher', icon: path.join(__dirname, 'icon256.png'),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: false }
  });
  win.removeMenu();
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  win.once('ready-to-show', () => win.show());
  if (process.env.B30_SHOT) require('./devshots')(win, app);
  win.on('closed', () => { win = null; });
}

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => app.quit());

// ---------- IPC ----------
ipcMain.handle('cfg:get', () => loadCfg());
ipcMain.handle('cfg:set', (_e, patch) => { const c = { ...loadCfg(), ...patch }; saveCfg(c); return c; });
ipcMain.handle('detect', () => {
  let c = loadCfg();
  let changed = false;
  if (!c.enginePath || !fs.existsSync(c.enginePath)) { const e = detectEngine(); if (e) { c.enginePath = e; changed = true; } }
  if (!c.dataDirManual && (!c.dataDir || !hasInstances(c.dataDir))) { const d = detectDataDir(c.enginePath); if (d) { c.dataDir = d; changed = true; } }
  if (changed) saveCfg(c);
  return c;
});
ipcMain.handle('pick:engine', async () => {
  const r = await dialog.showOpenDialog(win, { title: 'Select beer30launcher.exe', properties: ['openFile'], filters: IS_WIN ? [{ name: 'Program', extensions: ['exe'] }] : [] });
  return r.canceled ? '' : r.filePaths[0];
});
ipcMain.handle('pick:folder', async () => {
  const r = await dialog.showOpenDialog(win, { title: 'Select the launcher data folder (the one containing "instances")', properties: ['openDirectory'] });
  return r.canceled ? '' : r.filePaths[0];
});
ipcMain.handle('instances:list', () => readInstances(loadCfg().dataDir));
ipcMain.handle('folder:open', (_e, p) => { if (p) shell.openPath(p); });
ipcMain.handle('engine:open', () => {
  const c = loadCfg();
  if (DEMO) return { ok: true };
  if (!c.enginePath || !fs.existsSync(c.enginePath)) return { ok: false, error: 'Engine not found. Set it in Settings.' };
  try {
    const p = spawn(c.enginePath, [], { cwd: path.dirname(c.enginePath), detached: true, stdio: 'ignore' });
    p.on('error', () => {}); p.unref();
    return { ok: true };
  } catch (err) { return { ok: false, error: String(err.message || err) }; }
});
ipcMain.handle('launch', (_e, { id, server }) => {
  const c = loadCfg();
  if (child) return { ok: false, error: 'A launch is already in progress.' };
  if (DEMO) {
    send('state', { state: 'launching', id });
    setTimeout(() => send('state', { state: 'running', id }), 2800);
    setTimeout(() => send('state', { state: 'idle', id }), 9000);
    return { ok: true };
  }
  if (!c.enginePath || !fs.existsSync(c.enginePath)) return { ok: false, error: 'Engine not found. Open Settings and point to beer30launcher.exe.' };
  const args = ['--launch', id];
  if (c.dataDirManual && c.dataDir) args.unshift('--dir', c.dataDir);
  if (server && server.trim()) args.push('--server', server.trim());
  try {
    child = spawn(c.enginePath, args, { cwd: path.dirname(c.enginePath), stdio: 'ignore' });
  } catch (err) { child = null; return { ok: false, error: String(err.message || err) }; }
  send('state', { state: 'launching', id });
  runningTimer = setTimeout(() => send('state', { state: 'running', id }), 7000);
  child.on('error', (err) => { clearTimeout(runningTimer); child = null; send('state', { state: 'idle', id, error: String(err.message || err) }); });
  child.on('exit', (code) => { clearTimeout(runningTimer); child = null; send('state', { state: 'idle', id, code }); });
  return { ok: true };
});
ipcMain.on('win', (_e, action) => {
  if (!win) return;
  if (action === 'min') win.minimize();
  else if (action === 'max') { win.isMaximized() ? win.unmaximize() : win.maximize(); }
  else if (action === 'close') win.close();
});
