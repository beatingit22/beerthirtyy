const { app, BrowserWindow, ipcMain, Menu, shell, safeStorage } = require('electron');
const path = require('path'), fs = require('fs');
const { Auth, DEFAULT_CLIENT_ID } = require('./lib/auth');
const { Launcher, listVersions } = require('./lib/launcher');
const { Spotify } = require('./lib/spotify');
const { Bridge } = require('./lib/bridge');

app.commandLine.appendSwitch('disable-gpu-shader-disk-cache');
if (!app.requestSingleInstanceLock()) app.quit();

let win, launcher, auth, spotify, bridge;
const dataDir = () => app.getPath('userData');
const dbFile = () => path.join(dataDir(), 'accounts.json');
const ENC = ['refreshToken', 'mcToken'];

// Tokens are encrypted with the OS keychain (DPAPI on Windows) when available.
const store = {
  load() {
    try {
      const db = JSON.parse(fs.readFileSync(dbFile(), 'utf8'));
      for (const a of Object.values(db.accounts || {}))
        for (const k of ENC) if (typeof a[k] === 'string' && a[k].startsWith('enc:')) a[k] = safeStorage.decryptString(Buffer.from(a[k].slice(4), 'base64'));
      return db;
    } catch { return {}; }
  },
  save(db) {
    const c = JSON.parse(JSON.stringify(db));
    if (safeStorage.isEncryptionAvailable())
      for (const a of Object.values(c.accounts || {})) for (const k of ENC) if (a[k]) a[k] = 'enc:' + safeStorage.encryptString(a[k]).toString('base64');
    fs.writeFileSync(dbFile(), JSON.stringify(c));
  }
};

function loadConfig() {
  const f = path.join(dataDir(), 'config.json');
  let cfg = {};
  try { cfg = JSON.parse(fs.readFileSync(f, 'utf8')); } catch { fs.writeFileSync(f, JSON.stringify({ msClientId: DEFAULT_CLIENT_ID, cosmetics: true }, null, 2)); }
  return cfg;
}
const send = (type, data) => win && !win.isDestroyed() && win.webContents.send('game:event', { type, ...data });

function createWindow() {
  Menu.setApplicationMenu(null);
  win = new BrowserWindow({
    width: 1320, height: 840, minWidth: 1040, minHeight: 700, backgroundColor: '#06111f', autoHideMenuBar: true,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true }
  });
  win.setMenuBarVisibility(false);
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^https:\/\//.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  win.loadFile(path.join(__dirname, 'ui', 'index.html'));
}

app.whenReady().then(() => {
  const cfg = loadConfig();
  auth = new Auth(store, process.env.BEER30_CLIENT_ID || cfg.msClientId);
  launcher = new Launcher(path.join(dataDir(), 'minecraft'), (type, data) => { send(type, data); if (type === 'exit' && bridge) bridge.stop(); });
  const spFile = path.join(dataDir(), 'spotify.json');
  const spStore = {
    load() {
      try {
        const d = JSON.parse(fs.readFileSync(spFile, 'utf8'));
        if (typeof d.refreshToken === 'string' && d.refreshToken.startsWith('enc:')) d.refreshToken = safeStorage.decryptString(Buffer.from(d.refreshToken.slice(4), 'base64'));
        return d;
      } catch { return {}; }
    },
    save(d) {
      const c = { ...d };
      if (c.refreshToken && safeStorage.isEncryptionAvailable()) c.refreshToken = 'enc:' + safeStorage.encryptString(c.refreshToken).toString('base64');
      fs.writeFileSync(spFile, JSON.stringify(c));
    }
  };
  spotify = new Spotify(spStore, url => shell.openExternal(url));
  bridge = new Bridge(spotify);
  createWindow();
});
app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
app.on('window-all-closed', () => { if (launcher) launcher.kill(); app.quit(); });

const safe = fn => async (...a) => { try { return await fn(...a); } catch (e) { return { error: e.message || String(e) }; } };

ipcMain.on('window:minimize', () => win && win.minimize());
ipcMain.on('window:maximize', () => win && (win.isMaximized() ? win.unmaximize() : win.maximize()));
ipcMain.on('window:close', () => win && win.close());

ipcMain.handle('versions:list', safe(() => listVersions()));
ipcMain.handle('ms:devicecode', safe(() => auth.startDeviceCode()));
ipcMain.handle('ms:token', safe((e, code) => auth.pollDeviceCode(code)));
ipcMain.handle('ms:accounts', safe(() => auth.list()));
ipcMain.handle('ms:remove', safe((e, uuid) => { auth.remove(uuid); return true; }));

ipcMain.handle('game:launch', safe(async (e, opts) => {
  const session = await auth.getSession(opts.accountUuid);
  const modsDir = path.join(dataDir(), 'beer30-mods'); fs.mkdirSync(modsDir, { recursive: true });
  const b = await bridge.start();
  try {
    await launcher.launch({ ...opts, session, bridge: b, cosmetics: loadConfig().cosmetics !== false, resDir: path.join(__dirname, 'resources'), modDirs: [modsDir, path.join(process.resourcesPath || '', 'mods')] });
  } catch (e) { bridge.stop(); throw e; }
  return { ok: true };
}));
ipcMain.handle('game:cancel', () => { launcher.cancel(); return true; });
ipcMain.handle('game:kill', () => { launcher.kill(); return true; });

ipcMain.handle('minecraft:open-folder', (e, instanceId) => {
  const dir = instanceId ? path.join(launcher.root, 'instances', String(instanceId).replace(/[^\w.-]+/g, '_')) : launcher.root;
  fs.mkdirSync(dir, { recursive: true });
  shell.openPath(dir);
  return true;
});
ipcMain.handle('updater:check', () => ({ available: false, latestVersion: app.getVersion(), currentVersion: app.getVersion() }));
ipcMain.handle('updater:install', () => true);

// Spotify (renderer only ever sees status/now-playing data, never tokens)
const SP = { status: 0, setClientId: 1, connect: 0, disconnect: 0, state: 0, command: 2, devices: 0, playlists: 0, search: 1 };
for (const name of Object.keys(SP)) ipcMain.handle('spotify:' + name, safe(async (e, ...a) => {
  if (name === 'command') return { result: await spotify.command(a[0], a[1] || {}) };
  return await spotify[name](...a);
}));
