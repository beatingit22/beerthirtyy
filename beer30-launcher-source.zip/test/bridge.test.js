const assert = require('assert'), http = require('http'), fs = require('fs'), os = require('os'), path = require('path');
const { Bridge } = require('../lib/bridge'); const C = require('../lib/cosmetics');
const req = (port, method, url, { token, host, body } = {}) => new Promise((res, rej) => {
  const r = http.request({ host: '127.0.0.1', port, method, path: url, headers: { ...(token ? { 'X-Beer30-Token': token } : {}), ...(host ? { Host: host } : {}), ...(body ? { 'Content-Type': 'application/json' } : {}) } }, resp => { let d = ''; resp.on('data', c => d += c); resp.on('end', () => res({ status: resp.statusCode, json: JSON.parse(d) })); });
  r.on('error', rej); if (body) r.write(body); r.end();
});
(async () => {
  let stateCalls = 0, cmds = [], connected = true;
  const sp = { status: () => ({ connected }), state: async () => { stateCalls++; return { active: true, playing: true, title: 'Cold One', artist: 'Busch', progressMs: 1, durationMs: 2, device: 'PC', art: 'x', uri: 'secret' }; }, command: async (c) => { cmds.push(c); if (c === 'next' && sp.fail) throw new Error('Spotify Premium is required'); } };
  const b = new Bridge(sp); const { port, token } = await b.start();
  assert.ok(port > 0 && token.length === 48);
  assert.strictEqual((await req(port, 'GET', '/spotify/state')).status, 401, 'no token');
  assert.strictEqual((await req(port, 'GET', '/spotify/state', { token: 'x'.repeat(48) })).status, 401, 'wrong token');
  assert.strictEqual((await req(port, 'GET', '/spotify/state', { token, host: 'evil.com' })).status, 403, 'rebinding host');
  const s = await req(port, 'GET', '/spotify/state', { token });
  assert.strictEqual(s.status, 200); assert.deepStrictEqual(Object.keys(s.json).sort(), ['active', 'artist', 'device', 'durationMs', 'playing', 'progressMs', 'title'], 'only safe fields leave the launcher');
  await req(port, 'GET', '/spotify/state', { token }); await req(port, 'GET', '/spotify/state', { token });
  assert.strictEqual(stateCalls, 1, 'cached - Spotify not hammered');
  const ok = await req(port, 'POST', '/spotify/cmd', { token, body: '{"cmd":"next"}' }); assert.strictEqual(ok.status, 200); assert.deepStrictEqual(cmds, ['next']);
  assert.strictEqual((await req(port, 'POST', '/spotify/cmd', { token, body: '{"cmd":"like"}' })).status, 400, 'not whitelisted');
  assert.strictEqual((await req(port, 'POST', '/spotify/cmd', { token, body: 'nope' })).status, 400);
  sp.fail = true; const f = await req(port, 'POST', '/spotify/cmd', { token, body: '{"cmd":"next"}' }); assert.strictEqual(f.status, 502); assert.match(f.json.error, /Premium/);
  connected = false; b.cache = null; assert.match((await req(port, 'GET', '/spotify/state', { token })).json.error, /connect Spotify/);
  b.stop();
  await assert.rejects(() => req(port, 'GET', '/spotify/state', { token }), 'server closed after game exit');

  // client mod jar install: only for 1.21.4, newest wins, stale removed
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'cm-')), game = path.join(tmp, 'game'), src = path.join(tmp, 'src'); fs.mkdirSync(path.join(game, 'mods'), { recursive: true }); fs.mkdirSync(src);
  fs.writeFileSync(path.join(game, 'mods', 'beer30-client-0.9.jar'), 'old'); fs.writeFileSync(path.join(game, 'mods', 'other.jar'), 'keep'); fs.writeFileSync(path.join(src, 'beer30-client-1.0.0.jar'), 'new');
  C.installClientMod(game, '1.21.4', [src, '/nonexistent'], () => {});
  assert.deepStrictEqual(fs.readdirSync(path.join(game, 'mods')).sort(), ['beer30-client-1.0.0.jar', 'other.jar']);
  C.installClientMod(game, '1.20.1', [src], () => {});
  assert.deepStrictEqual(fs.readdirSync(path.join(game, 'mods')), ['other.jar'], 'removed on other versions so Fabric does not refuse to start');
  console.log('bridge + client-mod install tests passed'); process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
