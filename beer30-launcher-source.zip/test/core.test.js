const assert = require('assert');
const L = require('../lib/launcher');

// rules: windows-only allow, osx disallow, feature-gated
const w = [{ action: 'allow', os: { name: 'windows' } }];
assert.strictEqual(L.ruleOk(undefined), true);
assert.strictEqual(L.ruleOk([{ action: 'allow' }, { action: 'disallow', os: { name: process.platform === 'win32' ? 'windows' : process.platform === 'darwin' ? 'osx' : 'linux' } }]), false);
assert.strictEqual(L.ruleOk(w), process.platform === 'win32');
assert.strictEqual(L.ruleOk([{ action: 'allow', features: { is_demo_user: true } }], {}), false);
assert.strictEqual(L.ruleOk([{ action: 'allow', features: { is_quick_play_multiplayer: true } }], { is_quick_play_multiplayer: true }), true);

// maven path (Fabric style + classifier)
assert.strictEqual(L.mavenPath('net.fabricmc:fabric-loader:0.16.9'), 'net/fabricmc/fabric-loader/0.16.9/fabric-loader-0.16.9.jar');
assert.strictEqual(L.mavenPath('org.lwjgl:lwjgl:3.3.3:natives-windows'), 'org/lwjgl/lwjgl/3.3.3/lwjgl-3.3.3-natives-windows.jar');

// inheritsFrom merge: child libs first, args concatenated, jar from parent
const parent = { id: '1.21.4', mainClass: 'net.minecraft.client.main.Main', libraries: [{ name: 'org.ow2.asm:asm:9.6', downloads: { artifact: { path: 'a/asm-9.6.jar', url: 'u1', sha1: 'x' } } }], arguments: { game: ['--username', '${auth_player_name}'], jvm: ['-cp', '${classpath}'] } };
const child = { id: 'fabric-loader-0.16.9-1.21.4', inheritsFrom: '1.21.4', mainClass: 'net.fabricmc.loader.impl.launch.knot.KnotClient', libraries: [{ name: 'org.ow2.asm:asm:9.7', url: 'https://maven.fabricmc.net/' }], arguments: { game: [], jvm: ['-DFabricMcEmu='] } };
const m = L.mergeVersion(child, parent);
assert.strictEqual(m.mainClass, child.mainClass);
assert.strictEqual(m._jarId, '1.21.4');
const plan = L.planLibraries(m, '/lib');
assert.strictEqual(plan.jars.length, 1, 'duplicate asm deduped, child wins');
assert.ok(plan.jars[0].url.startsWith('https://maven.fabricmc.net/org/ow2/asm/asm/9.7/'));

// old-style natives
const old = { libraries: [{ name: 'org.lwjgl.lwjgl:lwjgl-platform:2.9.4', natives: { windows: 'natives-windows', linux: 'natives-linux', osx: 'natives-osx' }, extract: { exclude: ['META-INF/'] }, downloads: { classifiers: { 'natives-windows': { path: 'n/w.jar', url: 'uw', sha1: 'a' }, 'natives-linux': { path: 'n/l.jar', url: 'ul', sha1: 'b' }, 'natives-osx': { path: 'n/o.jar', url: 'uo', sha1: 'c' } } } }] };
const op = L.planLibraries(old, '/lib');
assert.strictEqual(op.jars.length, 0); assert.strictEqual(op.natives.length, 1);

// argument expansion with rules + placeholders + feature-gated quick play
const vars = { auth_player_name: 'Steve', quickPlayMultiplayer: 'mc.example.com:25565' };
const args = L.expandArgs(['--username', '${auth_player_name}', { rules: [{ action: 'allow', features: { is_quick_play_multiplayer: true } }], value: ['--quickPlayMultiplayer', '${quickPlayMultiplayer}'] }, { rules: [{ action: 'allow', features: { is_demo_user: true } }], value: '--demo' }], vars, { is_quick_play_multiplayer: true });
assert.deepStrictEqual(args, ['--username', 'Steve', '--quickPlayMultiplayer', 'mc.example.com:25565']);
assert.deepStrictEqual(L.splitArgs('-XX:+UseG1GC "-Dfoo=a b" -Xss1M'), ['-XX:+UseG1GC', '-Dfoo=a b', '-Xss1M']);
console.log('all core tests passed');
