const assert = require('assert');
const { Auth } = require('../lib/auth');
let db = {}; const store = { load: () => JSON.parse(JSON.stringify(db)), save: d => { db = d; } };
const calls = [];
global.fetch = async (url, o = {}) => {
  calls.push(url);
  const j = (status, body) => ({ ok: status < 400, status, text: async () => JSON.stringify(body), json: async () => body });
  if (url.includes('/devicecode')) return j(200, { device_code: 'DC', user_code: 'ABCD', verification_uri: 'https://www.microsoft.com/link', expires_in: 900, interval: 5 });
  if (url.includes('/token')) return j(200, { access_token: 'MSAT', refresh_token: 'RT' });
  if (url.includes('user.auth.xboxlive')) { assert.ok(JSON.parse(o.body).Properties.RpsTicket === 'd=MSAT'); return j(200, { Token: 'XBL', DisplayClaims: { xui: [{ uhs: 'UHS' }] } }); }
  if (url.includes('xsts')) return j(200, { Token: 'XSTS' });
  if (url.includes('login_with_xbox')) { assert.strictEqual(JSON.parse(o.body).identityToken, 'XBL3.0 x=UHS;XSTS'); return j(200, { access_token: 'MCAT', expires_in: 86400 }); }
  if (url.includes('minecraft/profile')) return j(200, { id: '0123456789abcdef0123456789abcdef', name: 'Steve' });
};
(async () => {
  const a = new Auth(store, 'cid');
  assert.strictEqual((await a.startDeviceCode()).userCode, 'ABCD');
  const r = await a.pollDeviceCode('DC');
  assert.strictEqual(r.status, 'success'); assert.strictEqual(r.profile.uuid, '01234567-89ab-cdef-0123-456789abcdef');
  assert.ok(!JSON.stringify(r).includes('MCAT'), 'tokens never sent to the UI');
  const s = await a.getSession(r.profile.uuid);
  assert.deepStrictEqual([s.name, s.accessToken], ['Steve', 'MCAT']);
  db.accounts[r.profile.uuid].mcExpires = Date.now() - 1; // force refresh path
  const s2 = await a.getSession(r.profile.uuid); assert.strictEqual(s2.accessToken, 'MCAT');
  assert.ok(calls.filter(u => u.includes('/token')).length === 2);
  await assert.rejects(() => a.getSession('nope'), /not signed in/);
  console.log('auth chain tests passed');
})().catch(e => { console.error(e); process.exit(1); });
