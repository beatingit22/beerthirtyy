const assert = require('assert'), fs = require('fs'), os = require('os'), path = require('path');
const C = require('../lib/cosmetics');
// options.txt handling
assert.strictEqual(C.enablePack('', 'file/x.zip'), 'resourcePacks:["vanilla","fabric","file/x.zip"]\n');
const o = C.enablePack('fov:90.0\nresourcePacks:["vanilla","fabric","file/a.zip"]\nlang:en_us\n', 'file/x.zip');
assert.ok(o.includes('fov:90.0') && o.includes('lang:en_us') && o.includes('["vanilla","fabric","file/a.zip","file/x.zip"]'));
assert.strictEqual(C.enablePack(o, 'file/x.zip'), o, 'idempotent');
// modrinth version pick + required dependency resolution + old-version cleanup (mocked)
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'b30-'));
fs.mkdirSync(path.join(tmp, 'mods')); fs.writeFileSync(path.join(tmp, 'mods', 'emotecraft-fabric-2.5.0.jar'), 'old');
const calls = [];
global.fetch = async (url) => {
  calls.push(url);
  const j = b => ({ ok: true, status: 200, json: async () => b, body: null });
  if (url.includes('/project/emotecraft/version')) { assert.ok(url.includes('1.21.4') && url.includes('fabric')); return j([{ version_type: 'beta', files: [], dependencies: [] }, { version_type: 'release', files: [{ primary: true, url: 'http://f/e.jar', filename: 'emotecraft-fabric-2.5.7.jar', hashes: {} }], dependencies: [{ dependency_type: 'required', project_id: 'P1' }, { dependency_type: 'optional', project_id: 'P2' }] }]); }
  return j([]); // everything else: no build for this version
};
require('../lib/util').download = async (u, d) => fs.writeFileSync(d, 'new');
(async () => {
  const logs = [];
  // cape changer: exactly one managed cape, user's own files untouched, 'none' and bad ids handled
  const res = fs.mkdtempSync(path.join(os.tmpdir(), 'res-')); fs.mkdirSync(path.join(res, 'capes'));
  for (const id of ['cape-busch-mountain', 'cape-rack-30']) fs.writeFileSync(path.join(res, 'capes', id + '.png'), id);
  const gd = fs.mkdtempSync(path.join(os.tmpdir(), 'gd-')); fs.mkdirSync(path.join(gd, 'Capes'));
  fs.writeFileSync(path.join(gd, 'Capes', 'beer30-cape.png'), 'old'); fs.writeFileSync(path.join(gd, 'Capes', 'mine.png'), 'mine');
  C.installCape(gd, res, 'cape-rack-30', () => {});
  assert.deepStrictEqual(fs.readdirSync(path.join(gd, 'Capes')).sort(), ['beer30-rack-30.png', 'mine.png']);
  C.installCape(gd, res, 'cape-none', () => {});
  assert.deepStrictEqual(fs.readdirSync(path.join(gd, 'Capes')), ['mine.png']);
  C.installCape(gd, res, '../../evil', () => {});
  assert.deepStrictEqual(fs.readdirSync(path.join(gd, 'Capes')).sort(), ['beer30-busch-mountain.png', 'mine.png'], 'bad id falls back to default');
  const pick = await C.pickVersion('emotecraft', '1.21.4');
  assert.strictEqual(pick.file.filename, 'emotecraft-fabric-2.5.7.jar'); assert.deepStrictEqual(pick.deps, ['P1']);
  await C.installMods(tmp, '1.21.4', (l, m) => logs.push(m));
  assert.deepStrictEqual(fs.readdirSync(path.join(tmp, 'mods')), ['emotecraft-fabric-2.5.7.jar'], 'old version replaced');
  assert.ok(calls.some(u => u.includes('/project/P1/')), 'required dependency requested');
  assert.ok(logs.some(m => /no Fabric build/.test(m)));
  console.log('cosmetics tests passed');
})().catch(e => { console.error(e); process.exit(1); });
