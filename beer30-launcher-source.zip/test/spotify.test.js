const assert = require('assert'), http = require('http');
const { Spotify, challengeOf, REDIRECT } = require('../lib/spotify');
// RFC 7636 appendix B test vector
assert.strictEqual(challengeOf('dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjXk'), 'E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM');

let data = {}; const store = { load: () => JSON.parse(JSON.stringify(data)), save: d => { data = d; } };
const CID = 'a'.repeat(32), calls = [];
let playerReply = () => ({ status: 200, body: {} }), tokenCount = 0, expireFirst = true;
const realFetch = global.fetch;
global.fetch = async (url, o = {}) => {
  if (String(url).startsWith('http://127.0.0.1')) return realFetch(url, o);
  calls.push({ url: String(url), method: o.method, body: o.body, auth: o.headers && o.headers.Authorization });
  const res = (status, body) => ({ ok: status < 400, status, json: async () => body });
  if (String(url).includes('accounts.spotify.com/api/token')) {
    const p = new URLSearchParams(o.body); tokenCount++;
    if (p.get('grant_type') === 'authorization_code') { assert.ok(p.get('code_verifier').length >= 43 && p.get('code') === 'CODE'); return res(200, { access_token: 'T1', refresh_token: 'R1', expires_in: 3600 }); }
    assert.strictEqual(p.get('refresh_token'), 'R1'); return res(200, { access_token: 'T2', expires_in: 3600 });
  }
  if (String(url).endsWith('/v1/me')) return res(200, { display_name: 'Ryan' });
  return playerReply(String(url), o);
};
(async () => {
  const sp = new Spotify(store, async url => {
    const u = new URL(url); assert.strictEqual(u.searchParams.get('code_challenge_method'), 'S256'); assert.strictEqual(u.searchParams.get('redirect_uri'), REDIRECT);
    assert.strictEqual(u.searchParams.get('client_id'), CID);
    // bad state first (must be rejected without consuming the flow), then the real redirect
    await realFetch(REDIRECT + '?code=EVIL&state=wrong').catch(() => {});
    setTimeout(() => realFetch(REDIRECT + `?code=CODE&state=${u.searchParams.get('state')}`), 20);
  });
  assert.throws(() => sp.setClientId('nope'), /32/);
  sp.setClientId(CID);
  // a wrong-state hit rejects the attempt (that is the safe behaviour); then connect properly
  await assert.rejects(() => sp.connect(), /state mismatch/);
  sp.openUrl = async url => { const u = new URL(url); setTimeout(() => realFetch(REDIRECT + `?code=CODE&state=${u.searchParams.get('state')}`), 20); };
  const st = await sp.connect();
  assert.strictEqual(st.connected, true); assert.strictEqual(st.name, 'Ryan'); assert.strictEqual(data.refreshToken, 'R1');

  // 204 = nothing playing
  playerReply = () => ({ ok: true, status: 204, json: async () => null });
  assert.deepStrictEqual(await sp.state(), { active: false, device: null });
  // normalised state
  playerReply = () => ({ ok: true, status: 200, json: async () => ({ is_playing: true, progress_ms: 1000, shuffle_state: true, repeat_state: 'track', device: { name: 'PC', id: 'D', volume_percent: 40 }, item: { uri: 'spotify:track:x', name: 'Song', duration_ms: 200000, artists: [{ name: 'A' }, { name: 'B' }], album: { name: 'Alb', images: [{ url: 'big' }, { url: 'mid' }] } } }) });
  const s = await sp.state(); assert.deepStrictEqual([s.title, s.artist, s.art, s.volume, s.shuffle, s.repeat], ['Song', 'A, B', 'mid', 40, true, 'track']);
  // commands hit the right endpoints
  playerReply = () => ({ ok: true, status: 204, json: async () => null });
  calls.length = 0;
  await sp.command('play', { uri: 'spotify:playlist:p1' }); await sp.command('play', { uri: 'spotify:track:t1', deviceId: 'D' }); await sp.command('volume', { percent: 140 });
  await sp.command('seek', { ms: 1234.6 }); await sp.command('repeat', { mode: 'context' }); await sp.command('like', { uri: 'spotify:track:t1' }); await sp.command('transfer', { deviceId: 'D' });
  const c = calls.map(x => `${x.method} ${x.url.replace('https://api.spotify.com/v1', '')}`);
  assert.deepStrictEqual(c, ['PUT /me/player/play', 'PUT /me/player/play?device_id=D', 'PUT /me/player/volume?volume_percent=100', 'PUT /me/player/seek?position_ms=1235', 'PUT /me/player/repeat?state=context', 'PUT /me/library?uris=spotify%3Atrack%3At1', 'PUT /me/player']);
  assert.strictEqual(calls[0].body, JSON.stringify({ context_uri: 'spotify:playlist:p1' })); assert.strictEqual(calls[1].body, JSON.stringify({ uris: ['spotify:track:t1'] }));
  await assert.rejects(() => sp.command('repeat', { mode: 'x' }), /bad repeat/); await assert.rejects(() => sp.command('nuke'), /Unknown/);
  // 401 triggers a refresh + retry
  let first = true; playerReply = () => { if (first) { first = false; return { ok: false, status: 401, json: async () => ({}) }; } return { ok: true, status: 204, json: async () => null }; };
  const before = tokenCount; await sp.command('pause'); assert.strictEqual(tokenCount, before + 1);
  // friendly errors
  playerReply = () => ({ ok: false, status: 403, json: async () => ({ error: { reason: 'PREMIUM_REQUIRED', message: 'x' } }) });
  await assert.rejects(() => sp.command('next'), /Premium/);
  playerReply = () => ({ ok: false, status: 404, json: async () => ({ error: { message: 'Player command failed: No active device found' } }) });
  await assert.rejects(() => sp.command('next'), /No active Spotify device/);
  playerReply = () => ({ ok: false, status: 429, json: async () => ({}) });
  await assert.rejects(() => sp.command('next'), /rate limiting/);
  // disconnect clears the refresh token
  sp.disconnect(); assert.strictEqual(sp.status().connected, false);
  console.log('spotify tests passed'); process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
