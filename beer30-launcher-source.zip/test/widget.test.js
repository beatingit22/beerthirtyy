const { JSDOM } = require('/tmp/jt/node_modules/jsdom'); const fs = require('fs'), assert = require('assert');
const calls = []; let connected = false;
const playing = { active: true, playing: true, progressMs: 5000, durationMs: 200000, uri: 'spotify:track:1', title: 'Cold One', artist: 'Busch', art: '', shuffle: false, repeat: 'off', volume: 30, volumeOk: true, device: 'PC', deviceId: 'D' };
const api = {
  status: async () => ({ clientId: '', connected, redirectUri: 'http://127.0.0.1:48721/callback', name: connected ? 'Ryan' : '' }),
  setClientId: async id => { calls.push(['cid', id]); return true; }, connect: async () => { connected = true; return {}; },
  state: async () => playing, devices: async () => [{ id: 'D', name: 'PC', type: 'Computer', active: true }], playlists: async () => [{ uri: 'spotify:playlist:9', name: 'Road Trip', image: '' }],
  search: async q => [{ kind: 'track', uri: 'spotify:track:7', name: q, sub: 'X', image: '' }],
  command: async (c, a) => { calls.push([c, a]); return { result: c === 'liked' ? false : null }; }, disconnect: async () => true
};
const dom = new JSDOM('<body></body>', { runScripts: 'outside-only', pretendToBeVisual: true });
dom.window.buschLightDesktop = { spotify: api };
dom.window.eval(fs.readFileSync(__dirname + '/../ui/spotify-widget.js', 'utf8'));
const d = dom.window.document, wait = ms => new Promise(r => setTimeout(r, ms));
(async () => {
  await wait(30);
  d.querySelector('#b30sp .fab').click(); await wait(50);
  assert.ok(d.querySelector('#sp-cid') && /Premium/.test(d.querySelector('.panel').textContent), 'setup screen shown with Premium note');
  assert.ok(d.querySelector('.panel').textContent.includes('http://127.0.0.1:48721/callback'));
  d.querySelector('#sp-cid').value = 'a'.repeat(32); d.querySelector('#sp-conn').click(); await wait(150);
  assert.deepStrictEqual(calls[0], ['cid', 'a'.repeat(32)]);
  assert.strictEqual(d.querySelector('#sp-t').textContent, 'Cold One'); assert.strictEqual(d.querySelector('#sp-pp').innerHTML, '&#10074;&#10074;'.replace(/&#10074;/g, '\u275A'));
  assert.ok(d.querySelector('.panel').textContent.includes('Road Trip'), 'playlists tab loaded');
  d.querySelector('#sp-pp').click(); await wait(20); d.querySelector('#sp-nx').click(); await wait(20); d.querySelector('#sp-sh').click(); await wait(20);
  d.querySelector('[data-uri="spotify:playlist:9"]').click(); await wait(20);
  const names = calls.map(c => c[0]); for (const n of ['pause', 'next', 'shuffle', 'play']) assert.ok(names.includes(n), n + ' sent');
  assert.strictEqual(JSON.stringify(calls.find(c => c[0] === 'shuffle')[1]), '{"on":true}');
  d.querySelector('[data-tab="search"]').click(); await wait(20);
  const q = d.querySelector('#sp-q'); q.value = 'cold'; q.dispatchEvent(new dom.window.Event('input')); await wait(600);
  assert.ok(d.querySelector('[data-uri="spotify:track:7"]'), 'search result rendered');
  d.querySelector('[data-tab="devices"]').click(); await wait(80); assert.ok(d.querySelector('[data-dev="D"]'));
  console.log('widget tests passed'); process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
