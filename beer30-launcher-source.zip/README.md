# Beer30 Busch Light Launcher v3

Same Busch Light look, but now a real launcher: Electron app with a real backend.

## What changed vs v2.5.5
The old .exe was a thin .NET wrapper that opened Edge in app-mode with web security turned off. A web page can't download
game files or start Java, so "Launch" never started Minecraft, and Microsoft login stopped after step 1 and then trusted a typed username.

v3 adds a Node/Electron backend (`lib/`) that does it properly:
- Microsoft device-code login -> Xbox Live -> XSTS -> Minecraft services -> ownership check -> profile. Tokens are encrypted with Windows DPAPI and never reach the UI. Sessions refresh silently.
- Every version from Mojang's manifest: releases, snapshots, old beta/alpha (grouped in the New Instance dropdown).
- Downloads + verifies (SHA-1) client, libraries, natives, assets (incl. legacy "virtual" assets), and the log4j config.
- Downloads the exact Java Mojang ships for that version (8 / 16 / 17 / 21 ...). No Java install needed.
- Real process launch with live logs, quick-play server join, memory/JVM args, Fabric loader.

## v3.1 cosmetics (on by default; set `"cosmetics": false` in config.json to turn off)
- **Beer30 decor** resource pack, auto-enabled on first launch of an instance: mountain panorama behind the title/multiplayer screens, Busch-blue buttons and menu lists, "BEER30 EDITION" banner, Beer30 splash texts. Works on any version (best on 1.21.x). Turn it off any time in Options > Resource Packs.
- **Fabric instances** also get Fabric API, **Emotecraft** (emote wheel, default key B) and **Client Capes** from Modrinth, newest build for that Minecraft version. Your Beer30 cape is in the instance's `Capes` folder; pick it with the "Change Cape" button on the title screen.
- Capes and emotes are client-side: you always see yours, others only if they run the same mods (Emotecraft also needs it on the server for others to see emotes). Mojang's real capes can't be faked for other players.
- Regenerate the pack: `python3 build/make-pack.py` (Pillow + numpy).

## v3.1.1
- Preset "Campfire" servers and the Mountain Cooler store tab are removed (add your own servers in the Servers tab).
- Lock-screen code is now **0214** (the old preset invite codes are removed, including from configs saved on this PC). The lock screen no longer prints codes. Owner PIN is unchanged. Note: approved GamerTags (Ryan, Owner, ...) still unlock it.
- 8 preset capes + "No Cape" in the Skins studio. The cape you **Apply** is the one the launcher puts in the instance's `Capes` folder at launch (Fabric instances); press "Change Cape" once on the title screen to wear it. Your own PNGs in `Capes` also show up in that cycle.
- Build order for UI patches on a pristine bundle: `node build/patch-ui.js` then `node build/patch-ui-3.1.js`.

## v3.2.0 Spotify
Round button (bottom-left) opens a Spotify remote: now playing, seek, volume, play/pause/next/previous, shuffle, repeat, like, playlists, search, device switching.
- It controls Spotify running on your PC or phone (Spotify Connect); audio doesn't play inside the launcher or the game window.
- **Premium required** to control playback. Since Feb 2026 Spotify also requires a Premium-owned Development Mode app per user: create one at developer.spotify.com/dashboard (Web API), add Redirect URI `http://127.0.0.1:48721/callback`, paste the Client ID in the launcher. Max 5 allowlisted users per app.
- Tokens stay in the main process (encrypted with Windows DPAPI); the UI only sees now-playing data.
- Spotify removed some endpoints in 2026 (browse, other users' playlists, batch lookups), search returns max 10 per type, and playlist contents only for playlists you own - so no browse/recommendation pages.

## v3.3.0 in-game client + Spotify bridge
- The launcher runs a localhost-only bridge during a game session (random port + secret, whitelisted commands, 1.5 s cache) and passes it to the game via JVM properties.
- Drop the built `beer30-client-*.jar` (see `beer30-client/README.md`) into `%APPDATA%\Beer30-BuschLight-Launcher\beer30-mods\`; it is copied into Fabric **1.21.4** instances on launch and removed from other versions so Fabric never refuses to start.

Not done yet: Forge / NeoForge installers (launches vanilla and logs a warning), mod downloads, skin changing.

## Microsoft client ID (important)
`%APPDATA%\Beer30-BuschLight-Launcher\config.json` has `msClientId`. Minecraft's servers only accept apps Mojang has approved.
The ID shipped in v2.5.5 is kept as the default, but if sign-in ends with "Invalid app registration", register your own:
1. portal.azure.com -> App registrations -> New (account type: "Personal Microsoft accounts only"), Authentication -> allow public client flows = Yes.
2. Submit the app at https://aka.ms/AppRegInfo for Mojang approval (can take days). 3. Put the Application (client) ID in config.json.

## Build
`npm install` then `npm run dist` (Windows, Node 20+) -> `dist/`. `npm test` runs the offline tests.
`node build/patch-ui.js` re-applies the UI patches to a pristine copy of the original bundle.
