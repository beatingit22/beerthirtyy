(() => {
  const api = window.buschLightDesktop && window.buschLightDesktop.spotify;
  if (!api) return;
  const $ = (t, c, h) => { const e = document.createElement(t); if (c) e.className = c; if (h != null) e.innerHTML = h; return e; };
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const fmt = ms => { const s = Math.max(0, Math.floor(ms / 1000)); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); };
  const call = async (p) => { const r = await p; if (r && r.error) throw new Error(r.error); return r; };

  const css = $('style', '', `
  #b30sp{position:fixed;left:14px;bottom:14px;z-index:2147483000;font:13px/1.35 system-ui,Segoe UI,sans-serif;color:#e0f2fe;user-select:none}
  #b30sp *{box-sizing:border-box}
  #b30sp .fab{width:44px;height:44px;border-radius:50%;border:1px solid #38bdf8;background:#0b2a52;color:#38bdf8;cursor:pointer;display:flex;align-items:center;justify-content:center;box-shadow:0 4px 16px #0008}
  #b30sp .fab:hover{background:#0e3a73}
  #b30sp .fab.on{background:#1db954;border-color:#1db954;color:#05230f}
  #b30sp .panel{position:absolute;left:0;bottom:54px;width:340px;max-height:560px;overflow:hidden;display:none;flex-direction:column;background:#07111e;border:1px solid #1e5a99;border-radius:14px;box-shadow:0 10px 40px #000a}
  #b30sp .panel.open{display:flex}
  #b30sp .hd{display:flex;align-items:center;gap:8px;padding:10px 12px;background:linear-gradient(90deg,#0b2a52,#0a1d38);border-bottom:1px solid #1e5a99;font-weight:700;letter-spacing:.3px}
  #b30sp .hd .x{margin-left:auto;cursor:pointer;color:#7dd3fc;background:none;border:0;font-size:16px}
  #b30sp .body{padding:12px;overflow-y:auto}
  #b30sp input[type=text]{width:100%;padding:8px 10px;border-radius:8px;border:1px solid #1e5a99;background:#0a1d38;color:#e0f2fe;outline:none;user-select:text}
  #b30sp input[type=text]:focus{border-color:#38bdf8}
  #b30sp button.b{padding:8px 12px;border-radius:8px;border:1px solid #1e5a99;background:#0e3a73;color:#e0f2fe;cursor:pointer}
  #b30sp button.b:hover{background:#14508f} #b30sp button.g{background:#1db954;border-color:#1db954;color:#05230f;font-weight:700}
  #b30sp button.g:hover{background:#1ed760}
  #b30sp .err{color:#fca5a5;margin-top:8px;font-size:12px} #b30sp .mut{color:#7dd3fc99;font-size:12px}
  #b30sp ol{margin:8px 0 8px 18px;padding:0;color:#bae6fd;font-size:12px} #b30sp li{margin:3px 0} #b30sp code{background:#0a1d38;padding:1px 5px;border-radius:4px;user-select:text;color:#fff}
  #b30sp .np{display:flex;gap:10px} #b30sp .art{width:76px;height:76px;border-radius:8px;background:#0a1d38 center/cover;flex:none}
  #b30sp .t{font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis} #b30sp .a{color:#7dd3fc;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:12px}
  #b30sp .info{min-width:0;flex:1}
  #b30sp .row{display:flex;align-items:center;gap:6px;margin-top:10px} #b30sp .row.c{justify-content:center;gap:10px}
  #b30sp .ic{width:34px;height:34px;border-radius:50%;border:0;background:none;color:#e0f2fe;cursor:pointer;font-size:16px;display:flex;align-items:center;justify-content:center}
  #b30sp .ic:hover{background:#0e3a73} #b30sp .ic.on{color:#1ed760} #b30sp .ic.play{background:#e0f2fe;color:#07111e;width:42px;height:42px;font-size:18px}
  #b30sp input[type=range]{flex:1;accent-color:#38bdf8;height:4px;cursor:pointer}
  #b30sp .tabs{display:flex;gap:4px;margin-top:12px;border-bottom:1px solid #1e5a99} #b30sp .tab{padding:6px 10px;cursor:pointer;color:#7dd3fc;border-bottom:2px solid transparent}
  #b30sp .tab.on{color:#fff;border-color:#38bdf8}
  #b30sp .list{margin-top:8px;max-height:200px;overflow-y:auto} #b30sp .it{display:flex;align-items:center;gap:8px;padding:5px;border-radius:8px;cursor:pointer}
  #b30sp .it:hover{background:#0e3a73} #b30sp .it .im{width:34px;height:34px;border-radius:5px;background:#0a1d38 center/cover;flex:none} #b30sp .it .tx{min-width:0;flex:1}
  #b30sp .it .tx div{white-space:nowrap;overflow:hidden;text-overflow:ellipsis} #b30sp .it .k{font-size:10px;color:#7dd3fc;text-transform:uppercase}
  #b30sp .dev.act{color:#1ed760}`);
  document.head.appendChild(css);

  const root = $('div'); root.id = 'b30sp';
  const fab = $('button', 'fab', '<span style="font-size:22px;line-height:1">&#9835;</span>');
  fab.title = 'Spotify';
  const panel = $('div', 'panel');
  root.append(panel, fab); document.body.appendChild(root);

  let shownActive = null, st = { clientId: '', connected: false, redirectUri: '' }, now = null, tab = 'playlists', devices = [], playlists = [], results = [], busy = false, err = '', open = false, poll = null, liked = false, lastUri = '', seeking = false, volDrag = false;
  const guard = async fn => { err = ''; try { await fn(); } catch (e) { err = e.message || String(e); } render(); };

  async function refreshStatus() { st = await call(api.status()); fab.classList.toggle('on', st.connected); }
  async function refreshNow() {
    if (!st.connected) return;
    try {
      now = await call(api.state());
      if (now.active && now.uri !== lastUri) { lastUri = now.uri; liked = false; api.command('liked', { uri: now.uri }).then(r => { liked = !!(r && r.result); paint(); }).catch(() => {}); }
      if (err && /rate/i.test(err)) err = '';
    } catch (e) { err = e.message; }
    if (open && st.connected && shownActive !== !!(now && now.active)) render(); else paint();
  }
  function startPoll() { stopPoll(); poll = setInterval(refreshNow, 3000); refreshNow(); }
  function stopPoll() { if (poll) clearInterval(poll); poll = null; }
  setInterval(() => { if (open && now && now.active && now.playing && !seeking) { now.progressMs += 500; paint(); } }, 500);

  fab.onclick = async () => { open = !open; panel.classList.toggle('open', open); if (open) { await refreshStatus(); render(); if (st.connected) { startPoll(); loadTab(); } } else stopPoll(); };

  function setup() {
    return `<div class="mut">Control Spotify from the launcher: play/pause, skip, volume, playlists, search and devices. Music plays in your Spotify app (PC or phone) - this is its remote.</div>
    <div class="mut" style="margin-top:8px"><b style="color:#fbbf24">Needs Spotify Premium.</b> Spotify now makes each person create their own free developer app (one-time, 2 minutes):</div>
    <ol><li>Open <code>developer.spotify.com/dashboard</code> and create an app (Web API).</li>
    <li>Add this Redirect URI exactly: <code>${esc(st.redirectUri)}</code></li>
    <li>Copy the app's <b>Client ID</b> and paste it below.</li>
    <li>Friends using their own account: add them under the app's <i>User Management</i> (max 5).</li></ol>
    <input type="text" id="sp-cid" placeholder="Spotify Client ID" value="${esc(st.clientId)}" spellcheck="false">
    <div class="row"><button class="b g" id="sp-conn">${st.clientId ? 'Connect Spotify' : 'Save & Connect'}</button><button class="b" id="sp-dash">Open dashboard</button></div>
    ${busy ? '<div class="mut" style="margin-top:8px">Waiting for you to approve in your browser...</div>' : ''}`;
  }
  function player() {
    const n = now;
    if (!n || !n.active) return `<div class="mut">Nothing playing${n && n.device ? ' on ' + esc(n.device) : ''}. Open Spotify on a device (or choose one below), then pick a playlist.</div><div id="sp-tabs"></div>`;
    return `<div class="np"><div class="art" id="sp-art"></div><div class="info"><div class="t" id="sp-t"></div><div class="a" id="sp-a"></div><div class="mut" id="sp-d"></div></div></div>
    <div class="row"><span class="mut" id="sp-cur" style="width:34px"></span><input type="range" id="sp-seek" min="0" max="1000" value="0"><span class="mut" id="sp-dur" style="width:34px;text-align:right"></span></div>
    <div class="row c"><button class="ic" id="sp-sh" title="Shuffle">&#8644;</button><button class="ic" id="sp-pv" title="Previous">&#9198;</button><button class="ic play" id="sp-pp" title="Play/Pause"></button><button class="ic" id="sp-nx" title="Next">&#9197;</button><button class="ic" id="sp-rp" title="Repeat">&#8635;</button><button class="ic" id="sp-lk" title="Like">&#9825;</button></div>
    <div class="row"><span class="mut">Vol</span><input type="range" id="sp-vol" min="0" max="100"></div><div id="sp-tabs"></div>`;
  }
  function tabsHtml() {
    const t = (id, l) => `<div class="tab ${tab === id ? 'on' : ''}" data-tab="${id}">${l}</div>`;
    let body = '';
    if (tab === 'search') body = `<input type="text" id="sp-q" placeholder="Search songs, albums, playlists" style="margin-top:8px">` + list(results, 'res');
    else if (tab === 'devices') body = `<div class="list">${devices.length ? devices.map(d => `<div class="it dev ${d.active ? 'act' : ''}" data-dev="${esc(d.id)}"><div class="tx"><div>${esc(d.name)}${d.active ? ' (playing here)' : ''}</div><div class="k">${esc(d.type)}</div></div></div>`).join('') : '<div class="mut" style="padding:8px">No devices found. Open Spotify on your PC or phone.</div>'}</div>`;
    else body = list(playlists, 'pl');
    return `<div class="tabs">${t('playlists', 'Playlists')}${t('search', 'Search')}${t('devices', 'Devices')}</div>${body}`;
  }
  function list(items, kind) {
    if (!items.length) return `<div class="mut" style="padding:8px">${kind === 'res' ? 'Type to search (up to 10 results each).' : 'No playlists found.'}</div>`;
    return `<div class="list">${items.map(i => `<div class="it" data-uri="${esc(i.uri)}"><div class="im" style="background-image:url('${esc(i.image)}')"></div><div class="tx"><div>${esc(i.name)}</div>${i.sub || i.kind ? `<div class="mut">${i.kind ? `<span class="k">${esc(i.kind)}</span> ` : ''}${esc(i.sub || '')}</div>` : ''}</div></div>`).join('')}</div>`;
  }

  function render() {
    const keepQ = (panel.querySelector('#sp-q') || {}).value;
    panel.innerHTML = `<div class="hd"><span style="color:#1ed760">&#9679;</span> Spotify ${st.connected && st.name ? `<span class="mut" style="font-weight:400">- ${esc(st.name)}</span>` : ''}<button class="x" id="sp-x" title="Close">&#10005;</button></div><div class="body">${st.connected ? player() : setup()}${err ? `<div class="err">${esc(err)}</div>` : ''}</div>`;
    panel.querySelector('#sp-x').onclick = () => { open = false; panel.classList.remove('open'); stopPoll(); };
    if (!st.connected) {
      panel.querySelector('#sp-dash').onclick = () => window.open('https://developer.spotify.com/dashboard');
      panel.querySelector('#sp-conn').onclick = () => guard(async () => { const cid = panel.querySelector('#sp-cid').value; busy = true; render(); await call(api.setClientId(cid)); try { await call(api.connect()); } finally { busy = false; } await refreshStatus(); startPoll(); loadTab(); });
      return;
    }
    shownActive = !!(now && now.active);
    const tabs = panel.querySelector('#sp-tabs'); tabs.innerHTML = tabsHtml();
    if (keepQ != null && panel.querySelector('#sp-q')) panel.querySelector('#sp-q').value = keepQ;
    tabs.querySelectorAll('.tab').forEach(t => t.onclick = () => { tab = t.dataset.tab; render(); loadTab(); });
    tabs.querySelectorAll('[data-uri]').forEach(e => e.onclick = () => guard(async () => { await call(api.command('play', { uri: e.dataset.uri, deviceId: now && now.deviceId || undefined })); setTimeout(refreshNow, 600); }));
    tabs.querySelectorAll('[data-dev]').forEach(e => e.onclick = () => guard(async () => { await call(api.command('transfer', { deviceId: e.dataset.dev })); await loadTab(); setTimeout(refreshNow, 800); }));
    const q = tabs.querySelector('#sp-q'); if (q) { let tm; q.oninput = () => { clearTimeout(tm); tm = setTimeout(() => guard(async () => { results = q.value.trim() ? await call(api.search(q.value.trim())) : []; const v = q.value; render(); const nq = panel.querySelector('#sp-q'); nq.value = v; nq.focus(); }), 400); }; }
    if (now && now.active) {
      const g = id => panel.querySelector(id), cmd = (c, a) => guard(async () => { await call(api.command(c, a)); setTimeout(refreshNow, 350); });
      g('#sp-pp').onclick = () => cmd(now.playing ? 'pause' : 'play'); g('#sp-nx').onclick = () => cmd('next'); g('#sp-pv').onclick = () => cmd('previous');
      g('#sp-sh').onclick = () => cmd('shuffle', { on: !now.shuffle }); g('#sp-rp').onclick = () => cmd('repeat', { mode: { off: 'context', context: 'track', track: 'off' }[now.repeat] });
      g('#sp-lk').onclick = () => guard(async () => { await call(api.command(liked ? 'unlike' : 'like', { uri: now.uri })); liked = !liked; });
      const sk = g('#sp-seek'); sk.oninput = () => { seeking = true; g('#sp-cur').textContent = fmt(sk.value / 1000 * now.durationMs); };
      sk.onchange = () => guard(async () => { const ms = sk.value / 1000 * now.durationMs; now.progressMs = ms; await call(api.command('seek', { ms })); seeking = false; });
      const v = g('#sp-vol'); v.disabled = !now.volumeOk; v.value = now.volume == null ? 50 : now.volume; v.oninput = () => { volDrag = true; };
      v.onchange = () => guard(async () => { await call(api.command('volume', { percent: +v.value })); volDrag = false; });
    }
    paint();
  }
  function paint() {
    if (!open || !now || !now.active || !st.connected) return;
    const g = id => panel.querySelector(id); if (!g('#sp-t')) return;
    g('#sp-art').style.backgroundImage = `url('${now.art}')`; g('#sp-t').textContent = now.title; g('#sp-a').textContent = now.artist; g('#sp-d').textContent = now.device ? 'on ' + now.device : '';
    g('#sp-pp').innerHTML = now.playing ? '&#10074;&#10074;' : '&#9654;';
    g('#sp-sh').classList.toggle('on', now.shuffle); g('#sp-rp').classList.toggle('on', now.repeat !== 'off'); g('#sp-rp').textContent = now.repeat === 'track' ? '\u21BB1' : '\u21BB';
    g('#sp-lk').classList.toggle('on', liked); g('#sp-lk').innerHTML = liked ? '&#9829;' : '&#9825;';
    if (!seeking) { g('#sp-seek').value = now.durationMs ? Math.min(1000, now.progressMs / now.durationMs * 1000) : 0; g('#sp-cur').textContent = fmt(now.progressMs); }
    g('#sp-dur').textContent = fmt(now.durationMs);
    if (!volDrag && now.volume != null) g('#sp-vol').value = now.volume;
  }
  async function loadTab() {
    if (!st.connected) return;
    try {
      if (tab === 'playlists' && !playlists.length) playlists = await call(api.playlists());
      if (tab === 'devices') devices = await call(api.devices());
      err = '';
    } catch (e) { err = e.message; }
    render();
  }
  refreshStatus().then(() => { if (st.connected) refreshNow(); });
})();
