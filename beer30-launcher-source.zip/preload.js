const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('buschLightDesktop', {
  isElectron: true,
  brand: 'Beer30 Busch Light Edition',
  version: '3.3.0',
  platform: process.platform,
  minimize: () => ipcRenderer.send('window:minimize'),
  maximize: () => ipcRenderer.send('window:maximize'),
  close: () => ipcRenderer.send('window:close'),
  getVersions: () => ipcRenderer.invoke('versions:list'),
  getMsDeviceCode: () => ipcRenderer.invoke('ms:devicecode'),
  pollMsToken: code => ipcRenderer.invoke('ms:token', code),
  removeAccount: uuid => ipcRenderer.invoke('ms:remove', uuid),
  launchGame: opts => ipcRenderer.invoke('game:launch', opts),
  cancelLaunch: () => ipcRenderer.invoke('game:cancel'),
  killGame: () => ipcRenderer.invoke('game:kill'),
  onGameEvent: cb => {
    const h = (e, d) => cb(d);
    ipcRenderer.on('game:event', h);
    return () => ipcRenderer.removeListener('game:event', h);
  },
  openFolder: id => ipcRenderer.invoke('minecraft:open-folder', id),
  checkForUpdates: () => ipcRenderer.invoke('updater:check'),
  installUpdate: () => ipcRenderer.invoke('updater:install'),
  spotify: Object.fromEntries(['status', 'setClientId', 'connect', 'disconnect', 'state', 'command', 'devices', 'playlists', 'search'].map(n => [n, (...a) => ipcRenderer.invoke('spotify:' + n, ...a)])),
  onUpdaterStatus: () => {}
});
